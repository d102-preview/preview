-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: j10d102.p.ssafy.io    Database: d102
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `common_question`
--

LOCK TABLES `common_question` WRITE;
/*!40000 ALTER TABLE `common_question` DISABLE KEYS */;
INSERT INTO `common_question` VALUES (1,1,'1분 자기소개 부탁드립니다.','2024-04-02 20:00:08','2024-04-02 20:00:08'),(2,1,'동료와 친구들은 본인을 어떻게 생각하나요?','2024-04-02 20:00:08','2024-04-02 20:00:08'),(3,1,'인생에서 가장 힘들었던 경험과 이를 어떻게 극복했나요?','2024-04-02 20:00:08','2024-04-02 20:00:08'),(4,1,'리더쉽을 발휘했던 경험에 대해서 말씀해주세요.','2024-04-02 20:00:08','2024-04-02 20:00:08'),(5,1,'회사를 고를 때 중요하게 생각하는 우선순위를 말씀해주세요.','2024-04-02 20:00:08','2024-04-02 20:00:08'),(6,1,'본인만의 갈등을 해결하는 방법에 대해서 말씀해주세요.','2024-04-02 20:00:08','2024-04-02 20:00:08'),(7,1,'인생에서 가장 소중한 가치에 대해서 말씀해주세요.','2024-04-02 20:00:08','2024-04-02 20:00:08'),(8,1,'가장 존경하는 인물은 누구입니까?','2024-04-02 20:00:08','2024-04-02 20:00:08'),(9,1,'팀워크를 발휘했던 경험에 대해 말씀해주세요.','2024-04-02 20:00:08','2024-04-02 20:00:08'),(10,1,'프로젝트 경험에 대해서 소개해주세요.','2024-04-02 20:00:08','2024-04-02 20:00:08');
/*!40000 ALTER TABLE `common_question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:21:30
