-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: j10d102.p.ssafy.io    Database: d102
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `common_script`
--

LOCK TABLES `common_script` WRITE;
/*!40000 ALTER TABLE `common_script` DISABLE KEYS */;
INSERT INTO `common_script` VALUES (1,1,3,'ㄹㄹㄴㅇㄹ','2024-04-03 16:45:34','2024-04-03 16:45:34'),(2,1,6,'99','2024-04-03 16:50:58','2024-04-03 16:50:58'),(3,1,1,'자기소개 작성하는 중입니다.','2024-04-03 17:08:05','2024-04-04 02:04:14'),(4,5,1,'1분 자기소개 스크립트 작성중입니다. !!','2024-04-03 22:00:25','2024-04-03 22:05:38'),(5,1,2,'책임감 있는 동료라고 생각합니다. 평소에 힘든 일을 도맡아 하고, 맡은 일을 끝까지 책임지기 위해 노력합니다.','2024-04-03 22:12:27','2024-04-03 22:12:59'),(6,5,10,'저는 AI 기반 면접 연습 및 피드백을 제공하는 프리뷰 서비스의 가장 열정을 가지고 임했습니다 해당 프로젝트를 진행하며 협업 및 소통 능력을 키울 수 있었고 프론트엔드 역량 또한 쌓을 수 있었습니다','2024-04-04 00:31:47','2024-04-04 00:31:47');
/*!40000 ALTER TABLE `common_script` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:21:30
